@echo off

cd /d "%~dp0"

if not exist "outputs\crazy-taxi-native\assets\" (

 echo Original game assets are missing. Read RELEASE-README.txt.

 pause

 exit /b 1

)

"outputs\crazy-taxi-native\bin\scene-viewer.exe" --source-startup-owner > launch.log 2>&1

if errorlevel 1 (

 type launch.log

 pause

)

