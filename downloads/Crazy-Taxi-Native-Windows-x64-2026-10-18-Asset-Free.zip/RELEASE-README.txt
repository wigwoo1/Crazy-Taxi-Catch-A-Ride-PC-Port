Experimental native Windows x64 prototype � asset-free

This is not a standalone playable download. Original game resources are required and are not included. Use your own USA ROM; SHA25639996ec9c561f68e16e5435b781bb7c73f4e0123c13002c109f8150ab6e89de5.

For users with an existing local development extraction: copy your outputs/crazy-taxi-native/assets directory into the same location under this extracted package. Run Launch.cmd from this package root. Do not copy saves or credentials into the public repository. A complete first-time extraction installer is still unfinished; the source includes individual extraction tools.

Verified on the development PC: strict379-module build;65 bitmap/80 digit/3 native4K rank comparisons; native start, drive, pause Retry and resume. Full-game fidelity, sustained60fps, physicalXbox and other-PC compatibility remain unverified. Diagnostic screenshots can contain staged states.
